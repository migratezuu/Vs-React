import { useState, useEffect } from 'react';
import JejuItem from '../components/JejuItem';
import boxStyle from './Jeju.module.css';


function Jeju() {

    const [jejuList, setJejuList] = useState([]);

    useEffect(
        () => {
            fetch('https://apis.data.go.kr/6500000/jjtb/locinfo?serviceKey=xJLwIe5cL%2BKtCx7gy50KwmeeF7H8wa7rEhg2PW%2ByWzpEwWjNKrSwPaI6ZTAxv3vvSm1OeIXMYfo0LONBqkIDJg%3D%3D&pageNo=1&numOfRows=10')
                        .then(res => res.json())
                        .then(jejudata => {
                            setJejuList(jejudata.data);
                        });
        },
        []
    );
    console.log(jejuList);


    return(
        <>
        <h2> 제주 API 불러오기 </h2>
        <div className={boxStyle.JejuBox}>
        {jejuList.map(jeju => <JejuItem key = {jeju.name} jeju={jeju}/>)}
        </div>
        </>
    );

}
export default Jeju;