function About() {

    return (
        <h1>소개</h1>
    );
}

export default About;