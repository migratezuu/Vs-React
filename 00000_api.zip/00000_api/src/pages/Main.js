function Main() {

    return (
        <h1>메인화면</h1>
    );
}

export default Main;