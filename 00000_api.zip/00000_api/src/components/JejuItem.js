import itemStyle from './JejuItem.module.css';
import { Link } from 'react-router-dom';

function JejuItem({ jeju }) {
    return (
        <Link to={`/jeju/${jeju.name}`}>
            <div className={itemStyle.JejuItem}>
                <h3>이름 : {jeju.name}</h3>
            </div>
        </Link>
    );
}
export default JejuItem;