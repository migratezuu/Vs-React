function Header() {

    return (
        <h1>제주 관광지 모음</h1>
    )
}

export default Header;