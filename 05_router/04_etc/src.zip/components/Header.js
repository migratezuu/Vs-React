function Header() {
    return (
        <h1>Welcome to Greedy Restaurant</h1>
    );
}

export default Header;