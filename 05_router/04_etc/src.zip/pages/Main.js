function Main() {
    return (
        <div>
            <h1>메인페이지</h1>
        </div>
    );
}

export default Main;